# resum
resume on HCM, ABAP consultant
